#!/usr/bin/env python3
"""Install only FastPing's site, transactionally. Ubuntu + systemd + Caddy 2.8+.

No packages are installed, no old services are stopped, no DNS is changed.
Run from the unpacked release using sudo python3 deploy-server.py.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import fcntl
import glob
import hashlib
import http.client
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import socket
import stat
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass

DOMAIN = 'fastping.it.com'
ALIASES = {DOMAIN, 'www.' + DOMAIN}
VERSION = '1.0.0'
INSTALL_ROOT = Path('/srv/fastping')
BACKUP_ROOT = Path('/var/backups/fastping')

@dataclass(frozen=True)
class Token:
    value: str
    start: int
    end: int
    line: int
    brace: bool = False

def tokens(text: str) -> list[Token]:
    """Position-preserving Caddyfile lexer for bounded edits, not evaluation.

    Quoted values, escaped characters, placeholders and heredocs are opaque.
    Unrecognized/unfinished structures are refused before any write.
    """
    result: list[Token] = []
    i = 0
    line = 1
    while i < len(text):
        if text[i].isspace():
            line += text[i] == '\n'
            i += 1
            continue
        if text[i] == '#':
            end = text.find('\n', i)
            i = len(text) if end < 0 else end
            continue
        start, start_line = i, line
        if text.startswith('<<', i):
            marker_end = i
            while marker_end < len(text) and not text[marker_end].isspace():
                marker_end += 1
            marker = text[i+2:marker_end]
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_-]*', marker):
                raise ValueError('Unsupported heredoc marker; no files changed.')
            content = text.find('\n', marker_end)
            if content < 0:
                raise ValueError('Unterminated heredoc.')
            closing = re.search(r'(?m)^[ \t]*' + re.escape(marker) + r'(?=\s|$)', text[content+1:])
            if not closing:
                raise ValueError('Unterminated heredoc.')
            i = content+1+closing.end()
            line += text[start:i].count('\n')
            result.append(Token('<heredoc>', start, i, start_line))
            continue
        if text[i] in ('"', '`'):
            quote = text[i]
            i += 1
            value = ''
            while i < len(text) and text[i] != quote:
                if quote == '"' and text[i] == '\\':
                    i += 1
                    if i == len(text):
                        raise ValueError('Unterminated quote escape.')
                value += text[i]
                line += text[i] == '\n'
                i += 1
            if i == len(text):
                raise ValueError('Unterminated quote.')
            i += 1
        else:
            value = ''
            while i < len(text) and not text[i].isspace():
                if text[i] == '\\' and i+1 < len(text):
                    i += 1
                value += text[i]
                i += 1
        result.append(Token(value, start, i, start_line, value in ('{','}') and text[start] not in ('"','`')))
    return result

def blocks(text: str, strict: bool = True) -> list[tuple[list[Token], int, int]]:
    ts = tokens(text)
    depth, header, result = 0, [], []
    start = 0
    skip_line = -1
    for token in ts:
        if token.line == skip_line:
            continue
        if depth == 0 and token.value == 'import':
            if header:
                raise ValueError('Ambiguous top-level import; no changes made.')
            skip_line = token.line
            continue
        if token.brace and token.value == '{':
            if depth == 0:
                start = header[0].start if header else token.start
            depth += 1
        elif token.brace and token.value == '}':
            depth -= 1
            if depth < 0:
                raise ValueError('Unbalanced Caddyfile.')
            if depth == 0:
                result.append((header, start, token.end))
                header = []
        elif depth == 0:
            header.append(token)
    if depth or (header and strict):
        raise ValueError('Installer needs explicit, balanced site blocks; no files changed.')
    return result

def discover(root: Path) -> dict[Path, str]:
    """Follow literal file/glob imports, refusing parameterized paths."""
    found: dict[Path, str] = {}
    def visit(path: Path) -> None:
        path = path.resolve(strict=True)
        if path in found:
            return
        text = path.read_text(encoding='utf-8')
        found[path] = text
        ts = tokens(text)
        for i, token in enumerate(ts[:-1]):
            if token.value != 'import':
                continue
            if i and ts[i-1].line == token.line:
                continue
            target = ts[i+1]
            if target.line != token.line:
                raise ValueError('Import without a target.')
            if '{' in target.value or '}' in target.value:
                raise ValueError('Parameterized file imports require manual review; no files changed.')
            pattern = Path(target.value)
            if not pattern.is_absolute():
                pattern = path.parent / pattern
            for child in sorted(glob.glob(str(pattern))):
                if Path(child).is_file():
                    visit(Path(child))
    visit(root)
    return found

def address(value: str) -> tuple[str, str] | None:
    value = value.rstrip(',')
    match = re.fullmatch(r'(?:(https?)://)?([A-Za-z0-9.-]+)(?::(80|443))?', value)
    if not match:
        return None
    scheme, host, port = match.groups()
    return host.lower(), scheme or ('http' if port == '80' else 'https')

def transport_directives(body: str) -> str:
    ts = tokens(body)
    depth = 0
    pieces = []
    i = 0
    while i < len(ts):
        t = ts[i]
        if depth == 0 and t.value in ('tls', 'bind') and (i == 0 or ts[i-1].line < t.line):
            start = t.start
            j = i+1
            while j < len(ts) and ts[j].line == t.line:
                j += 1
            if j > i+1 and ts[j-1].brace and ts[j-1].value == '{':
                local = 1
                while j < len(ts) and local:
                    local += (ts[j].brace and ts[j].value == '{') - (ts[j].brace and ts[j].value == '}')
                    j += 1
                if local:
                    raise ValueError('Unbalanced TLS block.')
            pieces.append(body[start:ts[j-1].end])
            i = j
            continue
        depth += (t.brace and t.value == '{') - (t.brace and t.value == '}')
        i += 1
    return '\n'.join(pieces)

def plan(files: dict[Path, str], root: Path, config: str) -> dict[Path, str]:
    root = root.resolve()
    changed: dict[Path, str] = {}
    aliases = {DOMAIN}
    transports: list[str] = []
    found = False
    for path, text in files.items():
        replacements = []
        for header, start, end in blocks(text, strict=path == root):
            parsed = [address(t.value) for t in header]
            targeted = [i for i, a in enumerate(parsed) if a and a[0] in ALIASES]
            if not targeted:
                continue
            if any(a is None for a in parsed):
                raise ValueError('FastPing shares a nonliteral site address; manual review required.')
            found = True
            aliases.update(parsed[i][0] for i in targeted)
            brace = next(t for t in tokens(text[start:end]) if t.brace and t.value == '{')
            body_start = start+brace.end
            body_end = end-1
            if any(parsed[i][1] == 'https' for i in targeted):
                transport = transport_directives(text[body_start:body_end])
                if transport:
                    transports.append(transport)
            keep = [t.value.rstrip(',') for i, t in enumerate(header) if i not in targeted]
            replacement = (' '.join(keep)+' {'+text[body_start:body_end]+'}') if keep else ''
            replacements.append((start,end,replacement))
        if replacements:
            for start,end,replacement in reversed(replacements):
                text = text[:start]+replacement+text[end:]
            changed[path] = text
    if len(set(transports)) > 1:
        raise ValueError('FastPing has different TLS/bind settings across site blocks; manual review required.')
    # Main file is explicit; imports and unrelated site bodies remain intact.
    text = changed.get(root, files[root])
    transport = transports[0]+'\n' if transports else ''
    new = '\n\n# FastPing toolbox '+VERSION+'\n'+', '.join(sorted(aliases))+' {\n'+transport+config+'\n}\n'
    changed[root] = text.rstrip()+new
    print('FastPing route: '+('replace existing block(s)' if found else 'add new dedicated block'))
    return changed

def run(args: list[str], *, capture: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(args, check=True, text=True, capture_output=capture)

def atomic(path: Path, data: bytes, mode: int, uid: int = 0, gid: int = 0) -> None:
    fd, name = tempfile.mkstemp(prefix='.'+path.name+'.', dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(name, mode)
        os.chown(name, uid, gid)
        os.replace(name, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(name)

def verify_payload(source: Path) -> None:
    manifest = json.loads((source/'checksums.json').read_text())
    for relative, expected_hash in manifest.items():
        path = source/relative
        if not path.resolve().is_relative_to(source.resolve()) or not path.is_file() or path.is_symlink():
            raise ValueError('Invalid payload path.')
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected_hash:
            raise ValueError('Payload checksum mismatch: '+relative)
    needed = {'FastPing.caddy','site/index.html','site/style.css','site/app.mjs','site/metrics.mjs','site/favicon.svg','site/robots.txt'}
    if not needed.issubset(manifest):
        raise ValueError('Incomplete payload manifest.')

def origin_check() -> None:
    # A loopback-only transport check: do not use this TLS policy for public checks.
    # Host is fixed, and only response identity/body/nonce are tested here.
    nonce = uuid.uuid4().hex
    class LocalOrigin(http.client.HTTPSConnection):
        def connect(self) -> None:
            raw = socket.create_connection(('127.0.0.1',443),self.timeout)
            try:
                self.sock = ssl._create_unverified_context().wrap_socket(raw,server_hostname=DOMAIN)
            except BaseException:
                raw.close()
                raise
    connection = LocalOrigin(DOMAIN,443,timeout=8)
    try:
        connection.request('GET','/ping?nonce='+nonce,headers={'Host':DOMAIN,'Connection':'close'})
        r = connection.getresponse()
        body = r.read()
        if r.status != 200 or r.getheader('X-FastPing-Service') != VERSION or r.getheader('X-FastPing-Nonce') != nonce or body.strip() != b'pong':
            raise ValueError('Origin /ping response did not match this release.')
    finally:
        connection.close()

def install(args: argparse.Namespace) -> None:
    if os.geteuid() != 0:
        raise ValueError('Run with sudo python3 deploy-server.py (an interactive terminal is supported).')
    source = Path(__file__).resolve().parent
    verify_payload(source)
    caddy = shutil.which('caddy')
    if not caddy:
        raise ValueError('Caddy must already be installed. Nothing changed.')
    version = run([caddy,'version'],capture=True).stdout
    match = re.search(r'v(\d+)\.(\d+)',version)
    if not match or tuple(map(int,match.groups())) < (2,8):
        raise ValueError('Caddy 2.8+ is required. Nothing changed; no automatic upgrade attempted.')
    run(['systemctl','is-active','--quiet','caddy'])
    service = run(['systemctl','show','caddy','-p','ExecStart','--value'],capture=True).stdout
    configured_path = Path(args.caddyfile).absolute()
    config_file = configured_path.resolve(strict=True)
    if (str(config_file) not in service and str(configured_path) not in service) or '--resume' in service:
        raise ValueError('Caddy service does not clearly load this Caddyfile. Nothing changed. Use --caddyfile for its actual path.')
    # Validate the existing baseline before modifying anything.
    run([caddy,'validate','--config',str(config_file),'--adapter','caddyfile'],capture=True)
    files = discover(config_file)
    base = INSTALL_ROOT
    if base.is_symlink() or (base.exists() and not base.is_dir()):
        raise ValueError('/srv/fastping must be a real directory.')
    base.mkdir(mode=0o755,exist_ok=True)
    current = base/'current'
    if current.exists() and not current.is_symlink():
        raise ValueError('/srv/fastping/current is not a release symlink; refusing to overwrite it.')
    old_link = os.readlink(current) if current.is_symlink() else None
    if old_link and not current.resolve().is_relative_to(base/'releases'):
        raise ValueError('Existing current symlink is outside FastPing releases.')
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    backup = BACKUP_ROOT/stamp
    backup.mkdir(parents=True,mode=0o700)
    os.chmod(backup.parent,0o700)
    originals = {p:(p.read_bytes(),p.stat()) for p in files}
    for p,(data,info) in originals.items():
        dest = backup/'config'/str(p).lstrip('/')
        dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        dest.write_bytes(data)
        os.chmod(dest,0o600)
    (backup/'state.json').write_text(json.dumps({'caddyfile':str(config_file),'old_link':old_link,'files':[{ 'path':str(p),'mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid} for p,(_,info) in originals.items()]},indent=2))
    release = base/'releases'/stamp
    release.mkdir(parents=True,mode=0o755)
    shutil.copytree(source/'site',release/'site')
    for p in (release/'site').rglob('*'):
        os.chmod(p,0o755 if p.is_dir() else 0o644)
    shutil.copy2(source/'deploy-server.py',release/'deploy-server.py')
    config = (source/'FastPing.caddy').read_text()
    changed = plan(files,config_file,config)
    # Reject port changes/hidden imported domains before touching disk where possible.
    snapshot = {p:data for p,(data,_) in originals.items()}
    modified: list[Path] = []
    try:
        for p in files:
            if p.read_bytes() != snapshot[p]:
                raise ValueError('Caddy configuration changed during deployment. Retry after the other edit finishes.')
        for p,text in changed.items():
            info = originals[p][1]
            atomic(p,text.encode(),stat.S_IMODE(info.st_mode),info.st_uid,info.st_gid)
            modified.append(p)
        run([caddy,'validate','--config',str(config_file),'--adapter','caddyfile'],capture=True)
        temporary_link = base/('.current-'+stamp)
        temporary_link.symlink_to(release)
        os.replace(temporary_link,current)
        run(['systemctl','reload','caddy'])
        last_error = None
        for _ in range(4):
            try:
                origin_check()
                last_error = None
                break
            except (OSError,ValueError,http.client.HTTPException) as exc:
                last_error = exc
                time.sleep(1)
        if last_error:
            raise last_error
    except BaseException:
        for p in modified:
            info = originals[p][1]
            atomic(p,snapshot[p],stat.S_IMODE(info.st_mode),info.st_uid,info.st_gid)
        if old_link:
            temp = base/('.rollback-'+stamp)
            temp.symlink_to(old_link)
            os.replace(temp,current)
        else:
            with contextlib.suppress(FileNotFoundError):
                current.unlink()
        # Even a failed reload can have changed the running service; restore baseline.
        try:
            run(['systemctl','reload','caddy'])
            print('Previous configuration and release restored.')
        except subprocess.CalledProcessError:
            print('RESTORE RELOAD FAILED. Backup: '+str(backup),file=sys.stderr)
        raise
    print('Installed FastPing '+VERSION+'; origin /ping verified.')
    print('Backup: '+str(backup))
    print('Rollback: sudo python3 /srv/fastping/current/deploy-server.py --rollback '+str(backup))
    print('Public URL: https://'+DOMAIN)
    print('Existing background services were not stopped or removed.')

def rollback(folder: Path) -> None:
    if os.geteuid() != 0:
        raise ValueError('Rollback requires sudo.')
    folder = folder.resolve(strict=True)
    if not folder.is_relative_to(BACKUP_ROOT):
        raise ValueError('Rollback must use a FastPing backup directory.')
    state = json.loads((folder/'state.json').read_text())
    # Keep a recovery snapshot in case restoring the selected backup fails validation.
    current_data = {}
    for entry in state['files']:
        p = Path(entry['path'])
        current_data[p] = (p.read_bytes(),p.stat())
    link = INSTALL_ROOT/'current'
    before = os.readlink(link) if link.is_symlink() else None
    try:
        for entry in state['files']:
            p = Path(entry['path'])
            atomic(p,(folder/'config'/str(p).lstrip('/')).read_bytes(),entry['mode'],entry['uid'],entry['gid'])
        run(['caddy','validate','--config',state['caddyfile'],'--adapter','caddyfile'],capture=True)
        if state['old_link']:
            temporary = link.parent/('.restore-'+uuid.uuid4().hex)
            temporary.symlink_to(state['old_link'])
            os.replace(temporary,link)
        else:
            link.unlink(missing_ok=True)
        run(['systemctl','reload','caddy'])
    except BaseException:
        for p,(data,info) in current_data.items():
            atomic(p,data,stat.S_IMODE(info.st_mode),info.st_uid,info.st_gid)
        if before:
            temporary = link.parent/('.restore-recovery-'+uuid.uuid4().hex)
            temporary.symlink_to(before)
            os.replace(temporary,link)
        else:
            link.unlink(missing_ok=True)
        run(['systemctl','reload','caddy'])
        raise
    print('Restored backup: '+str(folder))

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--caddyfile',default='/etc/caddy/Caddyfile')
    parser.add_argument('--rollback',type=Path)
    args = parser.parse_args()
    try:
        lock_dir = Path('/run/fastping-toolbox')
        if lock_dir.is_symlink():
            raise ValueError('Unsafe lock directory.')
        lock_dir.mkdir(mode=0o700,exist_ok=True)
        with open(lock_dir/'install.lock','a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            if args.rollback:
                rollback(args.rollback)
            else:
                install(args)
        return 0
    except subprocess.CalledProcessError as exc:
        print('FAILED: '+str(exc),file=sys.stderr)
        # Avoid printing potentially sensitive contents from an existing server config.
        print('Caddy/systemd rejected the operation. Existing configuration was retained or restored.',file=sys.stderr)
        return 1
    except (OSError,ValueError,RuntimeError,http.client.HTTPException) as exc:
        print('FAILED: '+str(exc),file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())

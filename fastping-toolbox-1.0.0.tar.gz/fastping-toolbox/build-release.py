#!/usr/bin/env python3
"""Build the complete, dependency-free release in this directory's parent."""
from pathlib import Path
import hashlib
import json
import tarfile

root=Path(__file__).resolve().parent
payload_names=['FastPing.caddy','deploy-server.py']+[str(p.relative_to(root)) for p in sorted((root/'site').iterdir()) if p.is_file()]
(root/'checksums.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in payload_names},indent=2)+'\n')
with tarfile.open(root/'payload.tar.gz','w:gz') as archive:
    for name in payload_names+['checksums.json']:
        archive.add(root/name,arcname=name,recursive=False)
(root/'payload.sha256').write_text(hashlib.sha256((root/'payload.tar.gz').read_bytes()).hexdigest()+'\n')
names=payload_names+['checksums.json','payload.tar.gz','payload.sha256','Deploy.ps1','README.md','package.json','preview.mjs','build-release.py']
names += [str(p.relative_to(root)) for p in sorted((root/'tests').iterdir()) if p.is_file()]
destination=root.parent/'fastping-toolbox-1.0.0.tar.gz'
with tarfile.open(destination,'w:gz') as archive:
    for name in names:
        archive.add(root/name,arcname='fastping-toolbox/'+name,recursive=False)
print(destination)
print('SHA256 '+hashlib.sha256(destination.read_bytes()).hexdigest())
print('Bytes '+str(destination.stat().st_size))

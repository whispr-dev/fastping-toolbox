// Development launcher: the Sites preview daemon owns this process.
// Uses the exact production Caddy handlers; no simulated timings or responses.
import {spawn} from 'node:child_process';
import {mkdtempSync,readFileSync,writeFileSync,rmSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url));
const work=mkdtempSync(join(tmpdir(),'fastping-preview-'));
const portIndex=process.argv.indexOf('--port');
const port=(portIndex>=0?process.argv[portIndex+1]:process.env.PORT)||'5173';
if(!/^\d+$/.test(port))throw Error('Invalid PORT');
const config=readFileSync(join(root,'FastPing.caddy'),'utf8').replace('/srv/fastping/current/site',JSON.stringify(join(root,'site')));
const file=join(work,'Caddyfile');
writeFileSync(file,`{\n admin off\n auto_https off\n}\n:${port} {\n${config}\n}\n`);
const localCaddy=join(root,'tools','caddy');
const child=spawn(process.env.FASTPING_CADDY||(existsSync(localCaddy)?localCaddy:'caddy'),['run','--config',file,'--adapter','caddyfile'],{stdio:'inherit'});
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>child.kill(signal));
child.on('error',error=>{console.error('Install Caddy 2.8+ or set FASTPING_CADDY to its executable:',error.message);rmSync(work,{recursive:true,force:true});process.exitCode=1;});
child.on('exit',code=>{rmSync(work,{recursive:true,force:true});process.exitCode=code??1;});

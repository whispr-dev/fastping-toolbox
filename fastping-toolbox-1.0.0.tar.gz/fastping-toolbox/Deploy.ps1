#requires -Version 7.0
[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_.-]*$')]
    [string]$SshAlias = 'nyc1',
    [ValidatePattern('^/[A-Za-z0-9_./-]+$')]
    [string]$Caddyfile = '/etc/caddy/Caddyfile'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Invoke-Checked {
    param([string]$Executable, [string[]]$ArgumentList)
    & $Executable @ArgumentList
    if ($LASTEXITCODE -ne 0) { throw "$Executable exited with code $LASTEXITCODE. Read the preceding message." }
}

foreach ($tool in @('ssh', 'scp', 'tar')) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "Required command not found: $tool" }
}
$root = $PSScriptRoot
$payload = Join-Path $root 'payload.tar.gz'
if (-not (Test-Path -LiteralPath $payload -PathType Leaf)) { throw 'payload.tar.gz is missing. Extract the complete release archive first.' }
$hashFile = Join-Path $root 'payload.sha256'
$wanted = (Get-Content -LiteralPath $hashFile -Raw).Trim()
$actual = (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $wanted) { throw 'The upload archive failed its SHA-256 check. Download and extract the release again.' }

Write-Host "Connecting through your existing SSH alias '$SshAlias'..."
$output = & ssh -o ConnectTimeout=15 $SshAlias 'umask 077; mktemp -d /tmp/fastping-deploy.XXXXXXXX'
if ($LASTEXITCODE -ne 0) { throw 'SSH connection failed. Nothing was deployed.' }
$remote = ($output | Select-Object -Last 1).Trim()
if ($remote -notmatch '^/tmp/fastping-deploy\.[A-Za-z0-9]{8}$') { throw 'The server did not return the expected temporary directory. Nothing was deployed.' }
try {
    Write-Host 'Uploading the complete site and installer...'
    Invoke-Checked -Executable 'scp' -ArgumentList @($payload, "${SshAlias}:$remote/payload.tar.gz")
    Write-Host 'Backing up FastPing routing, validating Caddy and installing the release...'
    Write-Host 'If sudo asks for your server password, type it here. Input is hidden.'
    # -tt is intentional: sudo can ask for a password. Do not use sudo -n.
    # This shell command contains only validated paths and fixed literal commands.
    $command = "set -eu; cd '$remote'; tar -xzf payload.tar.gz; if [ `"`$(id -u)`" = 0 ]; then python3 deploy-server.py --caddyfile '$Caddyfile'; else sudo python3 deploy-server.py --caddyfile '$Caddyfile'; fi"
    Invoke-Checked -Executable 'ssh' -ArgumentList @('-tt', '-o', 'ConnectTimeout=15', $SshAlias, $command)
} finally {
    # Remote path came from mktemp and is strictly validated above.
    & ssh -o BatchMode=yes -o ConnectTimeout=8 $SshAlias "rm -rf -- '$remote'"
    if ($LASTEXITCODE -ne 0) { Write-Warning "Upload staging remains at $remote; the site is unaffected." }
}

Write-Host 'Checking the public HTTPS route through Cloudflare...'
$allPassed = $true
$nonce = [guid]::NewGuid().ToString('N')
try {
    $response = Invoke-WebRequest -Uri "https://fastping.it.com/ping?nonce=$nonce" -TimeoutSec 15 -MaximumRedirection 0 -SkipHttpErrorCheck
    if ([int]$response.StatusCode -ne 200 -or [string]$response.Headers['X-FastPing-Service'] -ne '1.0.0' -or [string]$response.Headers['X-FastPing-Nonce'] -ne $nonce -or ([string]$response.Content).Trim() -ne 'pong') {
        throw 'The public pong did not match this release; check Cloudflare redirects, cache rules or challenges.'
    }
    Write-Host 'PASS: public /ping, version marker and fresh-response nonce.'
    $homeResponse = Invoke-WebRequest -Uri 'https://fastping.it.com/' -TimeoutSec 15 -MaximumRedirection 0 -SkipHttpErrorCheck
    if ([int]$homeResponse.StatusCode -ne 200 -or [string]$homeResponse.Content -notmatch 'YOUR POCKET NETWORK TOOLBOX') { throw 'The public home page was replaced or redirected.' }
    $ipResponse = Invoke-WebRequest -Uri "https://fastping.it.com/ip?nonce=$nonce" -TimeoutSec 15 -MaximumRedirection 0 -SkipHttpErrorCheck
    $ipValue = ([string]$ipResponse.Content).Trim()
    $parsedIp = $null
    if ([int]$ipResponse.StatusCode -ne 200 -or -not [System.Net.IPAddress]::TryParse($ipValue, [ref]$parsedIp)) { throw 'The public /ip response was not an IP address.' }
    Write-Host "PASS: home page and public /ip ($ipValue)."
    foreach ($code in @(200, 204, 403, 404, 429, 500)) {
        $test = Invoke-WebRequest -Uri "https://fastping.it.com/status/$($code)?nonce=$([guid]::NewGuid().ToString('N'))" -TimeoutSec 15 -MaximumRedirection 0 -SkipHttpErrorCheck
        if ([int]$test.StatusCode -ne $code -or [string]$test.Headers['X-FastPing-Service'] -ne '1.0.0') {
            $allPassed = $false
            Write-Warning "Expected HTTP $code; received $($test.StatusCode). A Cloudflare rule may replace this intentional test response."
        } else { Write-Host "PASS: intentional HTTP $code." }
    }
} catch {
    $allPassed = $false
    Write-Warning $_.Exception.Message
}
if (-not $allPassed) {
    Write-Warning 'The origin deployment passed, but a public check failed. Preserve this output for troubleshooting; do not assume all public tools are working yet.'
    exit 2
}
Write-Host ''
Write-Host 'FastPing is live and publicly verified: https://fastping.it.com' -ForegroundColor Green

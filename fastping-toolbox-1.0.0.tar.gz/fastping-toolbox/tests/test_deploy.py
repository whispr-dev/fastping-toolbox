import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock
import argparse
import subprocess

spec = importlib.util.spec_from_file_location('deploy',Path(__file__).parents[1]/'deploy-server.py')
deploy = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = deploy
spec.loader.exec_module(deploy)

class RoutingTests(unittest.TestCase):
    def plan(self,text):
        root=Path('/etc/caddy/Caddyfile')
        return deploy.plan({root:text},root,'respond "NEW"')[root]

    def test_other_site_unchanged_and_target_removed(self):
        other='other.example {\n respond "keep { braces }" # }\n}\n'
        result=self.plan('{\n email admin@example.org\n}\n'+other+'fastping.it.com {\n reverse_proxy localhost:5555\n}\n')
        self.assertIn(other,result)
        self.assertNotIn('localhost:5555',result)
        self.assertEqual(result.count('fastping.it.com {'),1)

    def test_shared_site_keeps_other_hosts_and_body(self):
        result=self.plan('fastping.it.com, other.example {\n reverse_proxy localhost:5555\n}\n')
        self.assertIn('other.example {\n reverse_proxy localhost:5555\n}',result)
        self.assertIn('fastping.it.com {\nrespond "NEW"',result)

    def test_heredoc_comments_and_placeholders_do_not_break_balancing(self):
        text='other.example {\n respond <<HTML\n<h1>{ not a block } # hi</h1>\nHTML 200\n}\nfastping.it.com {\n header X-Thing {remote_host}\n respond `literal } {`\n}\n'
        result=self.plan(text)
        self.assertIn('<h1>{ not a block } # hi</h1>',result)
        self.assertNotIn('X-Thing',result)

    def test_explicit_tls_and_bind_preserved(self):
        result=self.plan('fastping.it.com {\n tls /etc/certs/cert.pem /etc/certs/key.pem\n bind 0.0.0.0\n reverse_proxy :8000\n}\n')
        self.assertIn('tls /etc/certs/cert.pem /etc/certs/key.pem',result)
        self.assertIn('bind 0.0.0.0',result)
        self.assertNotIn('reverse_proxy',result)

    def test_imports_and_idempotence(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'Caddyfile'
            child=Path(folder)/'site.caddy'
            fragment=Path(folder)/'headers.txt'
            root.write_text('import *.caddy\n')
            child.write_text('fastping.it.com {\n import headers.txt\n reverse_proxy :8000\n}\n')
            fragment.write_text('header X-Example example\n')
            files=deploy.discover(root)
            first=deploy.plan(files,root,'respond "NEW"')
            files.update(first)
            second=deploy.plan(files,root,'respond "NEW"')
            self.assertEqual(second[root].count('fastping.it.com {'),1)
            self.assertEqual(first[child],'\n')
            self.assertEqual(files[fragment],'header X-Example example\n')

    def test_unsafe_structures_fail_closed(self):
        for text in ['fastping.it.com\nreverse_proxy :8000\n','fastping.it.com {\n','fastping.it.com, {$OTHER} {\n respond hi\n}\n']:
            with self.assertRaises(ValueError): self.plan(text)

    def test_quoted_single_braces_are_not_blocks(self):
        result=self.plan('other.example {\n respond "}"\n}\nfastping.it.com {\n respond "{"\n}\n')
        self.assertIn('other.example {\n respond "}"\n}',result)

class TransactionTests(unittest.TestCase):
    def scenario(self, fail_origin):
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder)
            root=folder/'Caddyfile'
            old='other.example {\n respond keep\n}\nfastping.it.com {\n reverse_proxy :8000\n}\n'
            root.write_text(old)
            base=folder/'install'
            backups=folder/'backups'
            commands=[]
            def run(args, **kwargs):
                commands.append(args)
                stdout=''
                if args[1:] == ['version']: stdout='v2.11.7'
                if args[:2] == ['systemctl','show']: stdout='ExecStart=/usr/bin/caddy run --config '+str(root)
                return subprocess.CompletedProcess(args,0,stdout,'')
            with mock.patch.object(deploy,'INSTALL_ROOT',base), mock.patch.object(deploy,'BACKUP_ROOT',backups), mock.patch.object(deploy,'run',side_effect=run), mock.patch.object(deploy.shutil,'which',return_value='/usr/bin/caddy'), mock.patch.object(deploy,'origin_check',side_effect=ValueError('test failure') if fail_origin else None), mock.patch.object(deploy.time,'sleep'):
                if fail_origin:
                    with self.assertRaises(ValueError): deploy.install(argparse.Namespace(caddyfile=str(root)))
                    self.assertEqual(root.read_text(),old)
                    self.assertFalse((base/'current').exists())
                    self.assertGreaterEqual(commands.count(['systemctl','reload','caddy']),2)
                else:
                    deploy.install(argparse.Namespace(caddyfile=str(root)))
                    self.assertTrue((base/'current/site/index.html').is_file())
                    self.assertTrue((base/'current/deploy-server.py').is_file())
                    self.assertIn('other.example {\n respond keep\n}',root.read_text())
                    self.assertNotIn('reverse_proxy :8000',root.read_text())
                    backup=next(backups.iterdir())
                    deploy.rollback(backup)
                    self.assertEqual(root.read_text(),old)
                    self.assertFalse((base/'current').exists())
                self.assertFalse(any('stop' in command or 'restart' in command for command in commands))

    def test_success_and_explicit_rollback(self): self.scenario(False)
    def test_failed_origin_restores_baseline(self): self.scenario(True)

if __name__=='__main__': unittest.main()

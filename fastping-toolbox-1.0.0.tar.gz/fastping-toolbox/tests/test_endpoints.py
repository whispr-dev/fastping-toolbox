"""Exercise real production Caddy handlers. Set FASTPING_CADDY or install Caddy."""
import http.client
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
import unittest

class EndpointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.binary=os.environ.get('FASTPING_CADDY') or shutil.which('caddy')
        if not cls.binary: raise unittest.SkipTest('Caddy executable unavailable')
        cls.temp=tempfile.TemporaryDirectory()
        root=Path(__file__).resolve().parents[1]
        with socket.socket() as port_socket:
            port_socket.bind(('127.0.0.1',0))
            cls.port=port_socket.getsockname()[1]
        handler=(root/'FastPing.caddy').read_text().replace('/srv/fastping/current/site',str(root/'site'))
        config=Path(cls.temp.name)/'Caddyfile'
        config.write_text('{\n admin off\n auto_https off\n}\n:'+str(cls.port)+' {\n'+handler+'\n}\n')
        cls.log=open(Path(cls.temp.name)/'caddy.log','wb')
        cls.process=subprocess.Popen([cls.binary,'run','--config',str(config),'--adapter','caddyfile'],stdout=cls.log,stderr=cls.log)
        for _ in range(50):
            try:
                cls.request('GET','/ping')
                return
            except OSError: time.sleep(.05)
        cls.process.terminate()
        cls.process.wait(timeout=8)
        cls.log.close()
        raise RuntimeError('Caddy test instance did not start')

    @classmethod
    def tearDownClass(cls):
        cls.process.terminate()
        cls.process.wait(timeout=8)
        cls.log.close()
        cls.temp.cleanup()

    @classmethod
    def request(cls,method,path,headers=None):
        connection=http.client.HTTPConnection('127.0.0.1',cls.port,timeout=2)
        try:
            connection.request(method,path,headers=headers or {})
            response=connection.getresponse()
            return response.status,dict(response.getheaders()),response.read()
        finally: connection.close()

    def test_status_and_security_contracts(self):
        for path,expected in [('/',200),('/ip',200),('/ping',200),('/status/200',200),('/status/204',204),('/status/403',403),('/status/404',404),('/status/429',429),('/status/500',500),('/status/999',404),('/missing',404)]:
            with self.subTest(path=path):
                status,headers,body=self.request('GET',path)
                self.assertEqual(status,expected)
                self.assertEqual(headers.get('X-Fastping-Service'),'1.0.0')
                self.assertEqual(headers.get('Cache-Control'),'no-store, max-age=0')
                self.assertEqual(headers.get('X-Content-Type-Options'),'nosniff')
                if path=='/status/204': self.assertEqual(body,b'')
                if path=='/status/429': self.assertEqual(headers.get('Retry-After'),'5')

    def test_nonce_body_and_method_guards(self):
        for nonce in ['first','second']:
            status,headers,body=self.request('GET','/ping?nonce='+nonce)
            self.assertEqual(body,b'pong')
            self.assertEqual(headers.get('X-Fastping-Nonce'),nonce)
            self.assertEqual(headers.get('Access-Control-Allow-Origin'),'*')
        for path in ['/ping','/ip','/status/500']:
            for method,expected in [('POST',405),('DELETE',405),('OPTIONS',204),('HEAD',500 if path.endswith('500') else 200)]:
                with self.subTest(path=path,method=method):
                    status,headers,body=self.request(method,path)
                    self.assertEqual(status,expected)
                    if method in ('HEAD','OPTIONS'): self.assertEqual(body,b'')
        self.assertEqual(self.request('POST','/')[0],405)

    def test_forged_ip_headers_are_ignored(self):
        _,_,body=self.request('GET','/ip',{'CF-Connecting-IP':'203.0.113.123','X-Forwarded-For':'203.0.113.123'})
        self.assertEqual(body,b'127.0.0.1')

    def test_assets_are_served_and_source_files_are_not(self):
        for path in ['/style.css','/app.mjs','/metrics.mjs','/favicon.svg','/robots.txt']:
            self.assertEqual(self.request('GET',path)[0],200,path)
        self.assertEqual(self.request('GET','/deploy-server.py')[0],404)

if __name__=='__main__': unittest.main()

#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$global:FastPingTestCalls = [System.Collections.Generic.List[string]]::new()
$global:FastPingTestWebCalls = [System.Collections.Generic.List[string]]::new()
function global:ssh {
    $line = $args -join ' '
    $global:FastPingTestCalls.Add($line)
    $global:LASTEXITCODE = 0
    if ($line -match 'mktemp') { '/tmp/fastping-deploy.AbCd1234' }
    if ($line -match 'sudo python3' -and $line -notmatch '-tt') { throw 'Interactive sudo terminal missing' }
}
function global:scp { $global:LASTEXITCODE = 0 }
function global:Invoke-WebRequest {
    param($Uri, $TimeoutSec, $MaximumRedirection, [switch]$SkipHttpErrorCheck)
    $global:FastPingTestWebCalls.Add([string]$Uri)
    $u = [uri]$Uri
    $headers = @{ 'X-FastPing-Service' = '1.0.0' }
    $content = ''; $status = 200
    if ($u.AbsolutePath -eq '/ping') {
        $content = 'pong'
        $headers['X-FastPing-Nonce'] = $u.Query.Substring(7)
    } elseif ($u.AbsolutePath -eq '/') { $content = 'YOUR POCKET NETWORK TOOLBOX' }
    elseif ($u.AbsolutePath -eq '/ip') { $content = '203.0.113.1' }
    else { $status = [int]($u.AbsolutePath.Split('/')[-1]) }
    [pscustomobject]@{ StatusCode=$status; Headers=$headers; Content=$content }
}
try {
    & (Join-Path $PSScriptRoot '../Deploy.ps1')
    if ($LASTEXITCODE -ne 0) { throw "Deployment script returned $LASTEXITCODE" }
    if ($global:FastPingTestWebCalls.Count -ne 9) { throw 'Public endpoint verification was incomplete' }
    if (-not ($global:FastPingTestCalls | Where-Object { $_ -match '-tt.*sudo python3' })) { throw 'Deployment command was not exercised' }
    if (-not ($global:FastPingTestCalls | Where-Object { $_ -match 'rm -rf' })) { throw 'Staging cleanup was not exercised' }
    'PowerShell deployment fixture: PASS'
} finally {
    Remove-Variable FastPingTestCalls,FastPingTestWebCalls -Scope Global -ErrorAction SilentlyContinue
    Remove-Item Function:\ssh,Function:\scp,Function:\Invoke-WebRequest -ErrorAction SilentlyContinue
}

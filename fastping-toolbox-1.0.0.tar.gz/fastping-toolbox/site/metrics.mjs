// Deliberately independent of the DOM so statistics and probe contracts can be tested.
export function statistics(entries) {
  const requests = entries.filter(e => e.kind === 'ok' || e.kind === 'fail');
  const values = requests.filter(e => e.kind === 'ok').map(e => e.ms).sort((a,b) => a-b);
  let previous = null, changes = [];
  for (const entry of entries) {
    if (entry.kind !== 'ok') { previous = null; continue; }
    if (previous !== null) changes.push(Math.abs(entry.ms - previous));
    previous = entry.ms;
  }
  const length = values.length;
  return {
    total: requests.length, failed: requests.filter(e => e.kind === 'fail').length,
    median: length ? (values[Math.floor((length-1)/2)] + values[Math.floor(length/2)])/2 : null,
    mean: length ? values.reduce((a,b) => a+b,0)/length : null,
    p95: length ? values[Math.ceil(length*.95)-1] : null,
    variation: changes.length ? changes.reduce((a,b) => a+b,0)/changes.length : null,
    min: length ? values[0] : null, max: length ? values[length-1] : null,
    gaps: entries.filter(e => e.kind === 'gap').length
  };
}
export function csv(entries) {
  const cell = value => '"' + String(value ?? '').replaceAll('"','""') + '"';
  const lines = [['timestamp_utc','kind','https_response_ms','http_status','reason','gap_ms'],
    ...entries.map(e => [new Date(e.at).toISOString(),e.kind,e.ms == null ? '' : e.ms.toFixed(3),e.status ?? '',e.reason ?? '',e.gapMs ?? ''])];
  return lines.map(row => row.map(cell).join(',')).join('\r\n')+'\r\n';
}
export async function probe({fetcher=fetch, nonce, signal, clock=()=>performance.now()}={}) {
  const start=clock();
  try {
    const response=await fetcher('/ping?nonce='+encodeURIComponent(nonce),{cache:'no-store',credentials:'omit',redirect:'error',signal});
    const body=await response.text();
    const ms=clock()-start;
    if(response.status!==200) return {kind:'fail',status:response.status,reason:'HTTP '+response.status};
    if(response.headers.get('X-FastPing-Service')!=='1.0.0' || body.trim()!=='pong')
      return {kind:'fail',status:response.status,reason:'Unexpected response (proxy, challenge or endpoint configuration)'};
    if(response.headers.get('X-FastPing-Nonce')!==String(nonce))
      return {kind:'fail',status:response.status,reason:'Cache or proxy mismatch: fresh origin response not verified'};
    return {kind:'ok',ms,status:200};
  } catch(error) {
    if(signal?.aborted) throw error;
    return {kind:'fail',reason:'Network request failed'};
  }
}

# FastPing toolbox 1.0.0

A small public connection toolbox for **https://fastping.it.com**. Static HTML,
CSS and JavaScript, with lightweight Caddy endpoints. No application daemon,
database, build pipeline, accounts, telemetry integration or API subscription.

## Deploy from Windows

Requirements: PowerShell 7, Windows OpenSSH (`ssh` and `scp`), `tar`, and the
already configured `nyc1` SSH alias. The server needs Python **3.10+**, Caddy
**2.8+**, systemd and sudo access. Tested with Python 3.11, Node 22, Caddy
2.11.7 and PowerShell 7.4.6. No Node runtime is needed on the server.

In PowerShell:

```powershell
Set-Location "$env:USERPROFILE\Downloads"
tar -xzf .\fastping-toolbox-1.0.0.tar.gz
Set-Location .\fastping-toolbox
.\Deploy.ps1
```

If sudo asks for your server password, type it in the terminal. It is hidden.
The SSH call deliberately allocates a terminal, so password-protected sudo
works. Your private key stays on your computer. Nothing changes in Cloudflare.

The installer checks the payload hashes, the running Caddy service and the
existing Caddyfile. It follows literal file/glob imports, backs up configuration,
removes FastPing addresses from their old site blocks, keeps other addresses
and their handlers, and adds the toolbox. Explicit TLS and bind directives
are retained. Unsupported or ambiguous configuration is refused before edits.
It validates the complete Caddy configuration before reload, checks the origin
pong, and restores the old configuration/release if that transaction fails.

The Windows script then checks the public home page, IP endpoint, nonce-verified
pong and all six status endpoints through Cloudflare. It returns exit code **2**
if the origin deployment succeeded but public verification failed. Public-check
failures do not automatically undo a working origin deployment: a Cloudflare
rule may need attention. Keep the diagnostic output if any check fails.

Default Caddyfile: `/etc/caddy/Caddyfile`. If yours is elsewhere:

```powershell
.\Deploy.ps1 -Caddyfile /actual/path/Caddyfile
```

Use the actual path from your server; the installer also checks that Caddy's
systemd `ExecStart` names that file. JSON, Docker-managed, API-only or unusual
parameterized Caddy configurations need review and are not rewritten blindly.

**The operational risk that matters:** existing Cloudflare redirect, challenge,
cache or error-page rules can override the origin. The public verification
detects these. Use Cloudflare Full (strict) with a working origin certificate;
Flexible mode can cause redirect loops with Caddy's automatic HTTPS. No
Cloudflare credentials are required or collected by this package.

Existing legacy background services, mail, databases, other domains and ports
are not stopped, deleted or changed. This replaces FastPing's web routing only.

## What visitors get

- An automatic ten-request quick check, repeatable on demand.
- A visible-tab watcher with 2, 5 or 10 second spacing **after** each request.
- A five-second timeout per probe, without overlapping scheduled probes.
- Latest HTTPS response time, median, adjacent variation and failed requests.
- A timeline showing the last 120 entries; failures and pauses break the line.
- Up to 10,000 entries in memory, including unmeasured gaps. CSV exports all
  retained entries with UTC timestamps and millisecond precision.
- A public IP card, refresh/copy controls and a VPN-check explanation.
- An HTTP playground with copyable Windows curl commands and real responses.
- Responsive layouts, keyboard focus states, labelled controls and no external
  fonts, JavaScript libraries, images, analytics or cookies added by the page.

The pulse checks **this browser → Cloudflare → FastPing's origin**, using fresh
nonces, `cache: no-store` and origin no-cache headers. It verifies the returned
nonce, version marker and pong body. Cached or altered responses fail visibly.
Elapsed time includes browser scheduling and connection setup when required;
connections may be reused. These are HTTPS request timings, **not ICMP ping,
packet loss, bandwidth or a general verdict on the visitor's internet**.

Variation is the mean absolute difference between consecutive successful
responses; failures and pauses break the sequence. P95 uses nearest rank.
Median and other summary values cover the retained session, not just the graph.
Quick-check completion messages refer only to that particular ten-request run.

Hidden tabs pause. Device sleep or scheduling delay appears as an unmeasured
gap, not a fabricated failed request. This is not an unattended uptime monitor.
Closing or clearing the tab discards the in-memory measurements.

## Endpoints

| Path | GET response | Notes |
| --- | --- | --- |
| `/ping` | `200`, body `pong` | `/ping?nonce=abc` echoes `abc` in `X-FastPing-Nonce` |
| `/ip` | `200`, plain-text address | IPv4 or IPv6 as seen on this connection |
| `/status/200` | `200 OK` | Intentional test response |
| `/status/204` | `204`, empty body | Intentional test response |
| `/status/403` | `403 Forbidden` | Intentional test response |
| `/status/404` | `404 Not Found` | Intentional test response |
| `/status/429` | `429 Too Many Requests` | Includes `Retry-After: 5` |
| `/status/500` | `500 Internal Server Error` | Intentional test response |

API routes accept GET, HEAD and OPTIONS. Unsupported methods return 405;
OPTIONS returns an empty 204. Public, credential-free CORS is enabled on API
routes; there is no arbitrary target proxy, user-provided command or webhook
storage. Unknown status codes return 404. API responses include
`X-FastPing-Service: 1.0.0`. Browser clients can read the nonce, version and
Retry-After response headers through CORS.

```powershell
curl.exe -i 'https://fastping.it.com/ping?nonce=hello'
curl.exe 'https://fastping.it.com/ip'
curl.exe -i 'https://fastping.it.com/status/429'
```

```bash
curl -i 'https://fastping.it.com/ping?nonce=hello'
curl 'https://fastping.it.com/ip'
curl -i 'https://fastping.it.com/status/429'
```

`/ip` trusts `CF-Connecting-IP` only when the immediate peer belongs to
Cloudflare's published IPv4/IPv6 ranges (verified 2026-10-25). Otherwise it
returns the immediate peer address. Arbitrary forwarded headers are ignored.
No global proxy trust settings are changed. An additional private proxy
between Cloudflare and Caddy would require adapting this rule. Future
Cloudflare range changes would require a configuration update.

The origin access log for this site uses Caddy's discard output. Hosting/CDN
providers still process connection information and may retain their own logs.
Cloudflare features configured outside this package can also add scripts or
cookies; the package makes no changes to those account settings.

## Files and recovery

```text
fastping-toolbox/
  Deploy.ps1               Windows upload + deploy + public verification
  payload.tar.gz           Ready-to-upload site, Caddy handlers and installer
  payload.sha256           Upload archive integrity check
  deploy-server.py         Transactional Ubuntu installer and rollback
  FastPing.caddy           Complete origin handler configuration
  checksums.json           Per-file payload integrity checks
  README.md
  build-release.py         Rebuilds this complete distribution
  package.json             Optional development/test commands
  preview.mjs              Optional local preview using real Caddy handlers
  site/
    index.html
    style.css
    app.mjs
    metrics.mjs
    favicon.svg
    robots.txt
  tests/
    metrics.test.mjs
    test_deploy.py
    test_endpoints.py
    Test-Deploy.ps1
```

Server assets live under `/srv/fastping/releases/<release-id>/site`, with
`/srv/fastping/current` pointing to the current release. Backups live under
`/var/backups/fastping/<backup-id>` and are readable by root only. The installer
prints the exact backup path. No files from the old application are deleted.

The installer prints a complete rollback command containing the exact backup
path. To restore that backup, SSH into `nyc1` and paste that command.

Rollback restores the saved Caddy configuration and prior release pointer,
validates and reloads Caddy. It does not manage old application services.
No automatic deletion of releases or backups is performed.

## Development and validation

There is no production build step and no npm dependency installation.
Optional development requires Node 22+ and Caddy 2.8+ on PATH. `preview.mjs`
also accepts `FASTPING_CADDY` or a locally installed executable at `tools/caddy`.
The preview uses the real Caddy handlers over local HTTP; its measured numbers
describe that local development connection, not NYC1 or the public domain.

```bash
node preview.mjs --port 5173
node --test tests/*.test.mjs
python3 -m unittest discover -s tests -p 'test_*.py' -v
pwsh -NoProfile -File tests/Test-Deploy.ps1
python3 build-release.py
```

The endpoint suite launches and terminates its own temporary real Caddy test
instance. It skips those four tests if Caddy is unavailable; install Caddy or
set `FASTPING_CADDY` for full verification. Deployment transaction tests mock
systemd and origin outcomes; they verify successful install, explicit rollback,
automatic rollback, shared-host preservation and no service stops/restarts.
The PowerShell test uses controlled SSH/web-response fixtures; it does not
connect to NYC1. Actual server/public deployment checks run in `Deploy.ps1`.

Official references used for the implementation:

- https://caddyserver.com/docs/caddyfile/directives/respond
- https://caddyserver.com/docs/caddyfile/directives/header
- https://caddyserver.com/docs/caddyfile/concepts
- https://www.cloudflare.com/ips-v4
- https://www.cloudflare.com/ips-v6
- https://developer.mozilla.org/en-US/docs/Web/API/Performance_API/Resource_timing

© 2026 whispr.dev.
